const activeButtons = document.querySelectorAll(".btn.active");
const currentOpsField = document.querySelector("#current-ops span")
const opsContainer = document.getElementById("ops_container")

const equalButton = document.getElementById("equals")
const clearBtn = document.getElementById("clear")