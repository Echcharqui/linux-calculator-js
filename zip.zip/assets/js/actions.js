let currentOps = "";
let opsHistory = []
let calculationError = ""

function write(event) {
    if (calculationError === "") {
        // Retrieve the visible text of the clicked button.
        const buttonValue = event.currentTarget.dataset.value;
        // Add it to the expression string.
        currentOps += buttonValue;
        currentOpsField.textContent = currentOps;
    }
}

function makeTheOperations() {
    if (calculationError === "") {
        try {
            const result = parseExpression(currentOps).splitExpression().convertTokens().evaluateTokens();
            currentOps = result;
            currentOpsField.textContent = result;
        } catch (error) {
            opsContainer.classList.add("error")
            calculationError = error
            console.log(calculationError);
            
        }
    }
}

function clearCurrentOpsField() {
    currentOps = "";
    calculationError = "";
    currentOpsField.textContent = "";
    opsContainer.classList.remove("error")
}

