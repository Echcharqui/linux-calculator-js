
// Add a click listener to every selected button.
activeButtons.forEach(button => {
    button.addEventListener("click", write);
});

equalButton.addEventListener("click", makeTheOperations);
clearBtn.addEventListener("click", clearCurrentOpsField);

